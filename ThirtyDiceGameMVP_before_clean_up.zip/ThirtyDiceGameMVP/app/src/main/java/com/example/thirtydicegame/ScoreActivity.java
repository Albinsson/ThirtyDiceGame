package com.example.thirtydicegame;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Score activity is the view where the hall of fame and the users score is displayed.
 */
public class ScoreActivity extends AppCompatActivity implements ScoreActivityContract.View {

    private Button sPlayAgainBtn;
    private Button sSaveHighScoreBtn;
    private EditText sEnterYourName;
    private TextView sScoreRounds;
    private TextView sScoreTotal;
    private TextView sHallOfFame;
    private Boolean isHighScoreSet = false;
    private ScoreActivityContract.Presenter sPresenter;
    private int[] score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_points);

        sPresenter = new ScoreActivityPresenter(this);

        Intent intent = getIntent();

        setScore(intent.getIntArrayExtra(GameActivity.SCORE));

        int[] score = intent.getIntArrayExtra(GameActivity.SCORE);

        sPresenter.setScoresFromIntent(intent.getIntArrayExtra(GameActivity.SCORE));

    }

    @Override
    public void initView() {


        sPlayAgainBtn = findViewById(R.id.playAgain);
        sSaveHighScoreBtn = findViewById(R.id.saveHighScoreBtn);
        sEnterYourName = findViewById(R.id.enterYourName);
        sScoreTotal = findViewById(R.id.totalScore);
        sHallOfFame = findViewById(R.id.hallOfFame);
        sScoreRounds = findViewById(R.id.scoreRounds);

        sPlayAgainBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        sSaveHighScoreBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sPresenter.setHighScore(sEnterYourName.getText().toString(), score);
            }
        });

    }

    @Override
    public void setView() {
        finish();
        Intent intent = new Intent(ScoreActivity.this, GameActivity.class);

        startActivity(intent);

    }

    public void setScoreRounds(String scoreRounds) {
        sScoreRounds.setText(scoreRounds);
    }

    public void setScoreTotal(String scoreTotal) {
        sScoreTotal.setText(scoreTotal);
    }

    public void setsHallOfFame(String hallOfFame) {
        sHallOfFame.setText("");
        sHallOfFame.setText(hallOfFame);
    }

    public void writeToHallOfFame(String hallOfFame) {


        if (getIsHighScoreSet() == false) {
            String previousHallOfFame = readHallOfFame();
            SharedPreferences prefs = this.getSharedPreferences("myPrefsKey", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.putString("hall_of_fame", hallOfFame);
            editor.commit();
            setHighScoreSet(true);
        }
    }

    public String readHallOfFame() {

        SharedPreferences prefs = this.getSharedPreferences("myPrefsKey", Context.MODE_PRIVATE);
        return prefs.getString("hall_of_fame", "");

    }

    /**
     * Sets score.
     *
     * @param score the score
     */
    private void setScore(int[] score) {
        this.score = score;
    }


    public void hideEnterNameToHighScore(Boolean hideFieldAndButton) {
        if (hideFieldAndButton == true) {
            sEnterYourName.setVisibility(View.GONE);
            sSaveHighScoreBtn.setVisibility(View.GONE);
        } else {
            sEnterYourName.setVisibility(View.VISIBLE);
            sSaveHighScoreBtn.setVisibility(View.VISIBLE);
        }

    }

    /**
     * Gets high score set.
     *
     * @return the high score set
     */
    private Boolean getIsHighScoreSet() {
        return isHighScoreSet;
    }

    public void setHighScoreSet(Boolean highScoreSet) {
        isHighScoreSet = highScoreSet;
    }
}
