package com.example.thirtydicegame;


/**
 * The Image helper returns the images for a dice roll.
 */
public class ImageHelper {

    /**
     * Get images int [ ].
     *
     * @param dieValues  the die values
     * @param holdStates the hold states
     * @return the int [ ]
     */
    public int[] getImages(int[] dieValues, Boolean[] holdStates) {


        int [] images = new int[6];

        images[0] = getImage(dieValues[0], holdStates[0]);
        images[1] = getImage(dieValues[1], holdStates[1]);
        images[2] = getImage(dieValues[2], holdStates[2]);
        images[3] = getImage(dieValues[3], holdStates[3]);
        images[4] = getImage(dieValues[4], holdStates[4]);
        images[5] = getImage(dieValues[5], holdStates[5]);

        return images;
    }


    /**
     * Get images int [ ].
     *
     * @param dieValues the die values
     * @return the int [ ]
     */
    public int [] getImages(int[] dieValues) {

        int [] images = new int[6];

        for (int i = 0; i < dieValues.length; i++){

            switch (dieValues[i]) {
                case 1: images[i] = R.drawable.white1; break;
                case 2: images[i] = R.drawable.white2; break;
                case 3: images[i] = R.drawable.white3; break;
                case 4: images[i] = R.drawable.white4; break;
                case 5: images[i] = R.drawable.white5; break;
                case 6: images[i] = R.drawable.white6; break;
            }
        }
        return images;
    }

    /**
     * Get image int.
     *
     * @param dieValue  the die value
     * @param holdState the hold state
     * @return the int
     */
    public int getImage(int dieValue, Boolean holdState){


        switch (dieValue) {
            case 1: return holdState? R.drawable.grey1 : R.drawable.white1;
            case 2: return holdState? R.drawable.grey2 : R.drawable.white2;
            case 3: return holdState? R.drawable.grey3 : R.drawable.white3;
            case 4: return holdState? R.drawable.grey4 : R.drawable.white4;
            case 5: return holdState? R.drawable.grey5 : R.drawable.white5;
            case 6: return holdState? R.drawable.grey6 : R.drawable.white6;
            default: return 0;
        }
    }
}
