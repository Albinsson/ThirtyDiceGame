package com.example.thirtydicegame;

import android.util.Log;

/**
 * The type Score helper.
 */
public class ScoreHelper {


    /**
     * The Score.
     */
    private int[] score = new int[]{0,0,0,0,0,0,0,0,0,0};
    /**
     * The Total score.
     */
    private int totalScore = 0;


    /**
     * Sets score.
     *
     * @param score    the score
     * @param category the category
     */
    public void setScore(int score, String category) {


        switch (category) {
            case "Low":
                this.score[0] = score; totalScore = totalScore + score;
                break;
            case "4":
                this.score[1] = score;totalScore = totalScore + score;
                break;
            case "5":
                this.score[2] = score;totalScore = totalScore + score;
                break;
            case "6":
                this.score[3] = score;totalScore = totalScore + score;
                break;
            case "7":
                this.score[4] = score;totalScore = totalScore + score;
                break;
            case "8":
                this.score[5] = score;totalScore = totalScore + score;
                break;
            case "9":
                this.score[6] = score;totalScore = totalScore + score;
                break;
            case "10":
                this.score[7] = score;totalScore = totalScore + score;
                break;
            case "11":
                this.score[8] = score;totalScore = totalScore + score;
                break;
            case "12":
                this.score[9] = score;totalScore = totalScore + score;
                break;

        }

    }

    /**
     * Get score int [ ].
     *
     * @return the int [ ]
     */
    public int[] getScore() {
        return this.score;
    }

}
