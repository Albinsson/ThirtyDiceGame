package com.example.thirtydicegame;

import android.widget.ImageView;

/**
 * The interface Game activity contract.
 */
public interface GameActivityContract {

    /**
     * The interface View.
     */
    interface View {
        /**
         * Init view.
         */
        void initView();

        /**
         * Sets game state.
         *
         * @param roundCounter the round counter
         * @param throwCounter the throw counter
         */
        void setGameState(String roundCounter, String throwCounter);

        /**
         * Sets dice images.
         *
         * @param diceDrawable the dice drawable
         */
        void setDiceImages(int[] diceDrawable);

        /**
         * Show score activity.
         *
         */
        void showScoreActivity();

        /**
         * Sets die hold image.
         *
         * @param imageView   the image view
         * @param dieDrawable the die drawable
         */
        void setDieHoldImage(ImageView imageView, int dieDrawable);

        /**
         * Gets throw counter.
         *
         * @return the throw counter
         */
        int getThrowCounter();

        /**
         * Sets throw counter.
         *
         * @param throwCounter the throw counter
         */
        void setThrowCounter(int throwCounter);

        /**
         * Gets round counter.
         *
         * @return the round counter
         */
        int getRoundCounter();

        /**
         * Sets round counter.
         *
         * @param roundCounter the round counter
         */
        void setRoundCounter(int roundCounter);

        /**
         * Get hold states boolean [ ].
         *
         * @return the boolean [ ]
         */
        Boolean[] getHoldStates();

        /**
         * Sets hold states.
         *
         * @param holdStates the hold states
         */
        void setHoldStates(Boolean[] holdStates);

        /**
         * Get die values int [ ].
         *
         * @return the int [ ]
         */
        int[] getDieValues();

        /**
         * Sets die values.
         *
         * @param dieValues the die values
         */
        void setDieValues(int[] dieValues);

        /**
         * Sets button text.
         *
         * @param buttonText the button text
         */
        void setButtonText(String buttonText);

        /**
         * Remove item from spinner.
         *
         * @param item the item
         */
        void removeItemFromSpinner(String item);

        /**
         * Gets current category.
         *
         * @return the current category
         */
        String getCurrentCategory();

        /**
         * Sets current category.
         *
         * @param currentCategory the current category
         */
        void setCurrentCategory(String currentCategory);

        /**
         * Init spinner.
         */
        void initSpinner();

        /**
         * Sets spinner dropdown to default.
         */
        void setSpinnerDropdownToDefault();
    }


    /**
     * The interface Dice model.
     */
    interface DiceModel {
        /**
         * Roll dice int [ ].
         *
         * @param dieValues     the die values
         * @param dieHoldStates the die hold states
         * @return the int [ ]
         */
        int[] rollDice(int[] dieValues, Boolean[] dieHoldStates);

        /**
         * Roll dice int [ ].
         *
         * @return the int [ ]
         */
        int[] rollDice();

    }

    /**
     * The interface Presenter.
     */
    interface Presenter {
        /**
         * On click throw.
         *
         */
        void onClickThrow();

        /**
         * On click die.
         *
         * @param dieNumber the die number
         * @param holdState the hold state
         * @param view      the view
         */
        void onClickDie(int dieNumber, Boolean holdState, ImageView view);

        /**
         * On item selected.
         * @param id          the id
         * @param spinnerText the spinner text
         */
        void onItemSelected(long id, String spinnerText);


        /**
         * Get score int [ ].
         *
         * @return the int [ ]
         */
        int [] getScore();

    }

    /**
     * The interface Points model.
     */
    interface PointsModel {
        /**
         * Gets points.
         *
         * @param dieValue   the die value
         * @param categories the categories
         * @return the points
         */
        int getPoints(int[] dieValue, String categories);
    }
}

