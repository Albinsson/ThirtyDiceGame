package com.example.thirtydicegame;

/**
 * The interface Score activity contract.
 */
public interface ScoreActivityContract {

    /**
     * The interface View.
     */
    interface View {
        /**
         * Init view.
         */
        void initView();

        /**
         * Sets view.
         *
         */
        void setView();

        /**
         * Sets score rounds.
         *
         * @param scoreRounds the score rounds
         */
        void setScoreRounds(String scoreRounds);

        /**
         * Sets score total.
         *
         * @param scoreTotal the score total
         */
        void setScoreTotal(String scoreTotal);

        /**
         * Sets hall of fame.
         *
         * @param hallOfFame the hall of fame
         */
        void setsHallOfFame(String hallOfFame);

        /**
         * Read hall of fame string.
         *
         * @return the string
         */
        String readHallOfFame();

        /**
         * Write to hall of fame.
         *
         * @param hallOfFame the hall of fame
         */
        void writeToHallOfFame(String hallOfFame);

        /**
         * Hide enter name to high score.
         *
         * @param hideFieldAndButton the hide field and button
         */
        void  hideEnterNameToHighScore(Boolean hideFieldAndButton);

        /**
         * Sets high score set.
         *
         * @param isHighScoreSet the is high score set
         */
        void setHighScoreSet(Boolean isHighScoreSet);
    }

    /**
     * The interface Model.
     */
    interface Model {

        /**
         * Gets round scores.
         *
         * @param intArrayExtra the int array extra
         * @return the round scores
         */
        String getRoundScores(int[] intArrayExtra);

        /**
         * Gets total score.
         *
         * @param intArrayExtra the int array extra
         * @return the total score
         */
        int getTotalScore(int[] intArrayExtra);

        /**
         * Gets hall of fame.
         *
         * @param previousHallOfFame the previous hall of fame
         * @param name               the name
         * @param score              the score
         * @return the hall of fame
         */
        String getHallOfFame(String previousHallOfFame, String name, int score);

        /**
         * Format hall of fame string.
         *
         * @param newHallOfFame the new hall of fame
         * @return the string
         */
        String formatHallOfFame(String newHallOfFame);
    }

    /**
     * The interface Presenter.
     */
    interface Presenter {

        /**
         * Sets high score.
         *
         * @param toString      the to string
         * @param intArrayExtra the int array extra
         */
        void setHighScore(String toString, int[] intArrayExtra);

        /**
         * Sets scores from intent.
         *
         * @param intArrayExtra the int array extra
         */
        void setScoresFromIntent(int[] intArrayExtra);
    }

}
