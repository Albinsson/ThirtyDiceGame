package com.example.thirtydicegame;

import java.util.ArrayList;
import java.util.List;

/**
 * The Game activity points models how a dice throw will be scored.
 */
public class GameActivityPointsModel implements GameActivityContract.PointsModel {

    /**
     * The Points.
     */
    private int points;

    public int getPoints(int[] dieValue, String categories) {


        points = 0;

        List<Integer> dieValueList = new ArrayList<Integer>();
        for (int i : dieValue) {
            dieValueList.add(i);
        }


        if (categories.equals("Low")) {
            for (int i = 0; i < dieValueList.size(); i++) {
                if (dieValueList.get(i) <= 3) {
                    this.points += dieValueList.get(i);

                }
            }
            return points;

        } else {
            dieValueList = oneDie(dieValueList, Integer.valueOf(categories));
            if (dieValueList.size() >= 2) {
                dieValueList = twoDice(dieValueList, Integer.valueOf(categories));
            }
            if (dieValueList.size() >= 3) {
                dieValueList = threeDice(dieValueList, Integer.valueOf(categories));
            }
            if (dieValueList.size() >= 4) {
                dieValueList = fourDice(dieValueList, Integer.valueOf(categories));
            }
            if (dieValueList.size() >= 5) {
                dieValueList = fiveDice(dieValueList, Integer.valueOf(categories));
            }
            if (dieValueList.size() >= 6) {
                sixDice(dieValueList, Integer.valueOf(categories));
            }
        }


        return points;
    }

    private void sixDice(List<Integer> dieValues, Integer category) {
        int sum = 0;
        for (int i = 0; i < dieValues.size(); i++) {
            sum += dieValues.get(i);
        }
        if (sum == category) {
            this.points = this.points + sum;
        }
    }

    private List<Integer> fiveDice(List<Integer> dieValues, Integer category) {

        for (int i = 0; i < dieValues.size(); i++) {
            for (int j = 0; j < dieValues.size(); j++) {
                for (int k = 0; k < dieValues.size(); k++) {
                    for (int l = 0; l < dieValues.size(); l++) {
                        for (int m = 0; m < dieValues.size(); m++) {
                            if (dieValues.get(i) + dieValues.get(j) + dieValues.get(k) + dieValues.get(l) + dieValues.get(m) == category) {
                                this.points = this.points + (dieValues.get(i) + dieValues.get(j) + dieValues.get(k) + dieValues.get(l) + dieValues.get(m));
                                dieValues.set(i, 0);
                                dieValues.set(j, 0);
                                dieValues.set(k, 0);
                                dieValues.set(l, 0);
                                dieValues.set(m, 0);
                            }
                        }
                    }
                }
            }

            dieValues = removeZerosFromArray(dieValues);
        }
        return dieValues;
    }

    private List<Integer> fourDice(List<Integer> dieValues, Integer category) {

        for (int i = 0; i < dieValues.size(); i++) {
            for (int j = i + 1; j < dieValues.size(); j++) {
                for (int k = j + 1; k < dieValues.size(); k++) {
                    for (int l = k + 1; l < dieValues.size(); l++) {
                        if (dieValues.get(i) + dieValues.get(j) + dieValues.get(k) + dieValues.get(l) == category) {
                            this.points = this.points + (dieValues.get(i) + dieValues.get(j) + dieValues.get(k) + dieValues.get(l));
                            dieValues.set(i, 0);
                            dieValues.set(j, 0);
                            dieValues.set(k, 0);
                            dieValues.set(l, 0);
                        }
                    }
                }
            }
        }

        dieValues = removeZerosFromArray(dieValues);
        return dieValues;
    }

    private List<Integer> threeDice(List<Integer> dieValues, Integer category) {

        for (int i = 0; i < dieValues.size(); i++) {
            for (int j = i + 1; j < dieValues.size(); j++) {
                for (int k = i + 2; k < dieValues.size(); k++) {
                    if (dieValues.get(i) + dieValues.get(j) + dieValues.get(k) == category) {
                        this.points = this.points + (dieValues.get(i) + dieValues.get(j) + dieValues.get(k));
                        dieValues.set(i, 0);
                        dieValues.set(j, 0);
                        dieValues.set(k, 0);
                    }

                }
            }

            dieValues = removeZerosFromArray(dieValues);

        }
        for (int i = 0; i < dieValues.size(); i++) {
            for (int j = i + 1; j < dieValues.size(); j++) {
                for (int k = i + 2; k < dieValues.size(); k++) {
                    if (dieValues.get(i) + dieValues.get(j) + dieValues.get(k) == category) {
                        this.points = this.points + (dieValues.get(i) + dieValues.get(j) + dieValues.get(k));
                        dieValues.set(i, 0);
                        dieValues.set(j, 0);
                        dieValues.set(k, 0);
                    }

                }
            }

            dieValues = removeZerosFromArray(dieValues);
        }


        return dieValues;
    }

    private List<Integer> twoDice(List<Integer> dieValues, int category) {

        for (int i = 0; i < dieValues.size(); i++) {
            for (int j = i + 1; j < dieValues.size(); j++)
                if (dieValues.get(i) + dieValues.get(j) == category) {
                    this.points = this.points + (dieValues.get(i) + dieValues.get(j));
                    dieValues.set(i, 0);
                    dieValues.set(j, 0);
                }
        }


        dieValues = removeZerosFromArray(dieValues);


        return dieValues;

    }

    private List<Integer> oneDie(List<Integer> dieValues, int category) {


        int size = dieValues.size();

        for (int i = 0; i < size; i++) {


            if (Integer.valueOf(dieValues.get(i)) == category) {
                this.points = this.points + dieValues.get(i);
                dieValues.set(i, 0);
            }
        }

        dieValues = removeZerosFromArray(dieValues);

        return dieValues;
    }

    private List<Integer> removeZerosFromArray(List<Integer> dieValues) {

        List<Integer> newDieValues = new ArrayList<Integer>();

        for (int i = 0; i < dieValues.size(); i++) {
            if (dieValues.get(i) != 0) {
                newDieValues.add(dieValues.get(i));
            }
        }
        return newDieValues;
    }
}
