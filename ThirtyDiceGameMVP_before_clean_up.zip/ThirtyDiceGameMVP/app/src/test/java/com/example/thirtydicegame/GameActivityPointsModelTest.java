package com.example.thirtydicegame;

import org.junit.Test;

import static org.junit.Assert.*;

public class GameActivityPointsModelTest {






   

    @Test
    public void getPoint_6_666623() {


        GameActivityPointsModel mPointsModel = new GameActivityPointsModel();

        int [] dieValues = new int[]{6, 6, 6, 6, 3, 2};
        String category = "6";
        int output = mPointsModel.getPoints(dieValues, category);

        int expected = 24;
        
        assertEquals(expected, output);
    }

    @Test
    public void getPoints_6_666666() {


        GameActivityPointsModel mPointsModel = new GameActivityPointsModel();

        int [] dieValues = new int[]{4,4,4,4,4,4};
        String category = "12";
        int output = mPointsModel.getPoints(dieValues, category);

        int expected = 12;

        assertEquals(expected, output);
    }
    @Test
    public void getPoints_6_222222__12() {

        GameActivityPointsModel mPointsModel = new GameActivityPointsModel();

        int [] dieValues = new int[]{2,2,2,2,2,2};
        String category = "6";
        int output = mPointsModel.getPoints(dieValues, category);

        int expected = 12;

        assertEquals(expected, output);
    }

    @Test
    public void getPoints_5_122122__10() {

        GameActivityPointsModel mPointsModel = new GameActivityPointsModel();

        int [] dieValues = new int[]{1,2,2,1,2,2};
        String category = "5";
        int output = mPointsModel.getPoints(dieValues, category);

        int expected = 10;

        assertEquals(expected, output);
    }

    @Test
    public void getPoints_6_663333__24() {

        GameActivityPointsModel mPointsModel = new GameActivityPointsModel();

        int [] dieValues = new int[]{6,6,3,3,3,3};
        String category = "12";
        int output = mPointsModel.getPoints(dieValues, category);

        int expected = 24;

        assertEquals(expected, output);
    }
}