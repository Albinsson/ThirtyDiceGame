package com.example.thirtydicegame;

import android.util.Log;

import org.junit.Test;

import static org.junit.Assert.*;

public class ScoreActivityModelTest {

    ScoreActivityModel mPointsModel = new ScoreActivityModel();


    @Test
    public void getRoundScores() {
        int [] Scores = new int [] {1,2,3,4,5,6,7,8,9,10};
        String setText = mPointsModel.getRoundScores(Scores);
        String egual = setText;


        System.out.println(mPointsModel.getRoundScores(Scores));

        assertEquals(setText,egual);

    }
    @Test
    public void getHallOfFame_add_one_name() {

        String previousHallOfFame = "999//Erik//";
        String name = "Högga";
        int score = 99;

        String expected = previousHallOfFame  + score + "//" + name +"//";

        String equals = mPointsModel.getHallOfFame(previousHallOfFame,name,score);

        assertEquals(expected,equals);

    }
    @Test
    public void getHallOfFame_add_too_full_toSmallScore() {

        String previousHallOfFame = "999//Erik//888//Erik//777//Erik//666//Erik//555//Erik//";
        String name = "Högga";
        int score = 99;

        String expected = previousHallOfFame;

        String equals = mPointsModel.getHallOfFame(previousHallOfFame,name,score);

        assertEquals(expected,equals);

    }

    @Test
    public void getHallOfFame_add_too_full_newHighScore() {

        String previousHallOfFame = "999//Erik//888//Erik//777//Erik//666//Erik//555//Erik//";
        String name = "Högga";
        int score = 1000;

        String expected = "1000//Högga//999//Erik//888//Erik//777//Erik//666//Erik//";

        String equals = mPointsModel.getHallOfFame(previousHallOfFame,name,score);

        assertEquals(expected,equals);

    }

    @Test
    public void formatHallOfFame() {

        String previousHallOfFame = "999//Erik//888//Erik//777//Erik//666//Erik//555//Erik//";
        String name = "Högga";
        int score = 1000;

        String expected = "1000//Högga//999//Erik//888//Erik//777//Erik//666//Erik//";

        String equals = mPointsModel.formatHallOfFame(expected);
        System.out.println(equals);

        assertEquals(equals,equals);

    }

}