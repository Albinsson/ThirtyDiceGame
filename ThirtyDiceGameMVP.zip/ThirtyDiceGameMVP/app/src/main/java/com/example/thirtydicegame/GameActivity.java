package com.example.thirtydicegame;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Game activity is the the first view that launches when the application starts.
 * The view handles the game play for the application
 */
public class GameActivity extends AppCompatActivity implements GameActivityContract.View {

    /**
     * The constant SCORE is used to access the score from ScoreActivity
     */
    public static final String SCORE = "score";


//    public static final String TOTAL_SCORE = "total_score";

    private TextView mTextView;
    private Button mButton;
    private Spinner mSpinner;
    private ImageView mDice1;
    private ImageView mDice2;
    private ImageView mDice3;
    private ImageView mDice4;
    private ImageView mDice5;
    private ImageView mDice6;

    private int throwCounter = 0;
    private int roundCounter = 1;
    private Boolean[] holdStates = {false, false, false, false, false, false};
    private int[] dieValues = new int[6];

    private String currentCategory;

    /**
     * The Spinner dropdown holds the options for the spinner used to choose category.
     */
    private ArrayList<String> spinnerDropdown = new ArrayList<>(Arrays.asList("Low", "4", "5", "6", "7", "8", "9", "10", "11", "12"));


    private GameActivityContract.Presenter mPresenter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mPresenter = new GameActivityPresenter(this);
    }

    @Override
    public void initView() {

        mTextView = findViewById(R.id.roundInformation);
        mButton = findViewById(R.id.btn);
        mSpinner = findViewById(R.id.points_spinner);

        mDice1 = findViewById(R.id.imageViewDice1);
        mDice2 = findViewById(R.id.imageViewDice2);
        mDice3 = findViewById(R.id.imageViewDice3);
        mDice4 = findViewById(R.id.imageViewDice4);
        mDice5 = findViewById(R.id.imageViewDice5);
        mDice6 = findViewById(R.id.imageViewDice6);

        ArrayAdapter<String> mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, spinnerDropdown);
        mAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpinner.setAdapter(mAdapter);

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPresenter.onClickThrow();
            }
        });

        mDice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holdStates[0] = !holdStates[0];
                mPresenter.onClickDie(dieValues[0], holdStates[0], mDice1);
            }
        });

        mDice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holdStates[1] = !holdStates[1];
                mPresenter.onClickDie(dieValues[1], holdStates[1], mDice2);
            }
        });

        mDice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holdStates[2] = !holdStates[2];
                mPresenter.onClickDie(dieValues[2], holdStates[2], mDice3);
            }
        });

        mDice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holdStates[3] = !holdStates[3];
                mPresenter.onClickDie(dieValues[3], holdStates[3], mDice4);
            }
        });

        mDice5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holdStates[4] = !holdStates[4];
                mPresenter.onClickDie(dieValues[4], holdStates[4], mDice5);
            }
        });

        mDice6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holdStates[5] = !holdStates[5];
                mPresenter.onClickDie(dieValues[5], holdStates[5], mDice6);
            }
        });


        //Listener for spinner where user can choose category for round
        mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String spinnerText = mSpinner.getSelectedItem().toString();
                mPresenter.onItemSelected(spinnerText);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }

    @Override
    public void setGameState(String roundCounter, String throwCounter) {
        mTextView.setText("Round: " + roundCounter + "\nThrow: " + throwCounter + " of 3");
    }

    @Override
    public void setDiceImages(int[] diceDrawable) {

        mDice1.setImageResource(diceDrawable[0]);
        mDice2.setImageResource(diceDrawable[1]);
        mDice3.setImageResource(diceDrawable[2]);
        mDice4.setImageResource(diceDrawable[3]);
        mDice5.setImageResource(diceDrawable[4]);
        mDice6.setImageResource(diceDrawable[5]);
    }

    @Override
    public void showScoreActivity() {
        Intent intent = new Intent(GameActivity.this, ScoreActivity.class);
        intent.putExtra(SCORE, mPresenter.getScore());
//        intent.putExtra(TOTAL_SCORE, mPresenter.getTotalScore());

        startActivity(intent);
    }

    @Override
    public void setDieHoldImage(ImageView imageView, int dieDrawable) {
        imageView.setImageResource(dieDrawable);
    }

    public int getThrowCounter() {
        return throwCounter;
    }

    public void setThrowCounter(int throwCounter) {
        this.throwCounter = throwCounter;
    }

    public int getRoundCounter() {
        return roundCounter;
    }

    public void setRoundCounter(int roundCounter) {
        this.roundCounter = roundCounter;
    }

    public Boolean[] getHoldStates() {
        return holdStates;
    }

    public void setHoldStates(Boolean[] holdStates) {
        this.holdStates = holdStates;
    }

    public int[] getDieValues() {
        return dieValues;
    }

    public void setDieValues(int[] dieValues) {
        this.dieValues = dieValues;
    }

    public void setButtonText(String buttonText) {
        mButton.setText(buttonText);
    }

    public void removeItemFromSpinner(String item) {
        spinnerDropdown.remove(item);
    }

    public void setSpinnerDropdownToDefault() {
        this.spinnerDropdown = new ArrayList<>(Arrays.asList("Low", "4", "5", "6", "7", "8", "9", "10", "11", "12"));
    }

    public void initSpinner() {
        ArrayAdapter<String> mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, spinnerDropdown);
        mSpinner.setAdapter(mAdapter);
    }

    public String getCurrentCategory() {
        return currentCategory;
    }

    public void setCurrentCategory(String currentCategory) {
        this.currentCategory = currentCategory;
    }
}
