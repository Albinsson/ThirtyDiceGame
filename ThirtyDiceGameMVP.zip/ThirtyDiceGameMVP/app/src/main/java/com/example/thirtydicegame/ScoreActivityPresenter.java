package com.example.thirtydicegame;

/**
 * The type Score activity presenter.
 */
public class ScoreActivityPresenter implements ScoreActivityContract.Presenter{

    private ScoreActivityContract.View sView;
    private ScoreActivityContract.Model sModel;

    /**
     * Instantiates a new Score activity presenter.
     *
     * @param v the v
     */
    public ScoreActivityPresenter(ScoreActivityContract.View v) {
        sView = v;
        initPresenter();
    }

    private void initPresenter() {
        sModel = new ScoreActivityModel();
        sView.initView();
        sView.hideEnterNameToHighScore(false);
        sView.setsHallOfFame(sModel.formatHallOfFame(sView.readHallOfFame()));
        sView.setHighScoreSet(false);
    }


    @Override
    public void setHighScore(String name,  int [] initArrayExtra) {

        int totalScore = sModel.getTotalScore(initArrayExtra);
        String previousHallOfFame = sView.readHallOfFame();

        String newHallOfFame = sModel.getHallOfFame(previousHallOfFame,name,totalScore);

        sView.writeToHallOfFame(newHallOfFame);

        String formattedHallOfFame = sModel.formatHallOfFame(newHallOfFame);

        sView.setsHallOfFame(formattedHallOfFame);

        sView.hideEnterNameToHighScore(true);
    }

    @Override
    public void setScoresFromIntent(int[] intArrayExtra) {
        sView.setScoreRounds(sModel.getRoundScores(intArrayExtra));
        sView.setScoreTotal(String.valueOf(sModel.getTotalScore(intArrayExtra)));
    }

}
