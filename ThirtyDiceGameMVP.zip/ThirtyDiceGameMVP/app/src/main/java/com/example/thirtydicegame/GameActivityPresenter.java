package com.example.thirtydicegame;

import android.widget.ImageView;

/**
 * The Game activity presenters the game play.
 */
public class GameActivityPresenter implements GameActivityContract.Presenter {

    private GameActivityContract.View mView;
    private GameActivityContract.DiceModel mDiceModel;
    private GameActivityContract.PointsModel mPointsModel;
    private ImageHelper imageHelper;
    private ScoreHelper scoreHelper;


    /**
     * Instantiates a new Game activity presenter.
     *
     * @param v the v
     */
    public GameActivityPresenter(GameActivityContract.View v) {
        mView = v;
        initPresenter();
    }

    private void initPresenter() {
//        mModel = new GameActivityModel();
        mDiceModel = new GameActivityDiceModel();
        mPointsModel = new GameActivityPointsModel();
        imageHelper = new ImageHelper();
        scoreHelper = new ScoreHelper();
        mView.initView();
    }

    @Override
    public void onClickThrow() {

        int[] diceRoll;
        int[] previousRoll;
        Boolean[] holdStates;


        switch (mView.getThrowCounter()) {
            case 0:
                diceRoll = mDiceModel.rollDice();


                mView.setHoldStates(new Boolean[]{false, false, false, false, false, false});
                mView.setDieValues(diceRoll);
                mView.setDiceImages(imageHelper.getImages(diceRoll));
                mView.setThrowCounter(mView.getThrowCounter() + 1);

                mView.setGameState(Integer.toString(mView.getRoundCounter()), Integer.toString(mView.getThrowCounter()));

                break;
            case 1:
                previousRoll = mView.getDieValues();
                holdStates = mView.getHoldStates();
                diceRoll = mDiceModel.rollDice(previousRoll, holdStates);
                mView.setDieValues(diceRoll);
                mView.setDiceImages(imageHelper.getImages(diceRoll, holdStates));
                mView.setThrowCounter(mView.getThrowCounter() + 1);
                mView.setGameState(Integer.toString(mView.getRoundCounter()), Integer.toString(mView.getThrowCounter()));
                break;
            case 2:
                previousRoll = mView.getDieValues();
                holdStates = mView.getHoldStates();
                diceRoll = mDiceModel.rollDice(previousRoll, holdStates);

                mView.setDieValues(diceRoll);
                mView.setDiceImages(imageHelper.getImages(diceRoll, holdStates));
                mView.setThrowCounter(mView.getThrowCounter() + 1);
                mView.setButtonText("Save");

                mView.setGameState(Integer.toString(mView.getRoundCounter()), Integer.toString(mView.getThrowCounter()));

                break;
            case 3:
                String category = mView.getCurrentCategory();
                int[] dieValues = mView.getDieValues();
                int points = mPointsModel.getPoints(dieValues, category);
                int roundCounter = mView.getRoundCounter();

                scoreHelper.setScore(points, category);
                mView.removeItemFromSpinner(category);
                mView.initSpinner();

                if (roundCounter < 10) {
                    mView.setRoundCounter(roundCounter + 1);
                } else {

                    mView.setSpinnerDropdownToDefault();
                    mView.initSpinner();
                    mView.setRoundCounter(1);
                    mView.showScoreActivity();
                }

                mView.setThrowCounter(0);
                mView.setButtonText("Roll Dice!");

                break;
        }

    }

    @Override
    public void onClickDie(int dieValue, Boolean holdState, ImageView view) {
        mView.setDieHoldImage(view, imageHelper.getImage(dieValue, holdState));
    }

    @Override
    public void onItemSelected(String spinnerText) {

        switch (spinnerText) {
            case "Low":
                mView.setCurrentCategory(spinnerText);
                break;
            case "4":
                mView.setCurrentCategory(spinnerText);
                break;
            case "5":
                mView.setCurrentCategory(spinnerText);
                break;
            case "6":
                mView.setCurrentCategory(spinnerText);
                break;
            case "7":
                mView.setCurrentCategory(spinnerText);
                break;
            case "8":
                mView.setCurrentCategory(spinnerText);
                break;
            case "9":
                mView.setCurrentCategory(spinnerText);
                break;
            case "10":
                mView.setCurrentCategory(spinnerText);
                break;
            case "11":
                mView.setCurrentCategory(spinnerText);
                break;
            case "12":
                mView.setCurrentCategory(spinnerText);
                break;

        }
    }

    public int[] getScore() {
        return scoreHelper.getScore();
    }

}
