package com.example.thirtydicegame;

/**
 * The Score activity models the hall of fame and converts points.
 */
class ScoreActivityModel implements ScoreActivityContract.Model {

    @Override
    public String getRoundScores(int[] intArrayExtra) {
        String pointsPerRound = "Points per Round: \n";
        String[] categories = new String[]{"low:", "4:\t\t", "5:\t\t", "6:\t\t", "7: \t\t", "8:\t", "9:\t", "10:\t", "11:\t", "12:\t"};

        for (int i = 0; i < intArrayExtra.length / 2; i++) {
            pointsPerRound += categories[i] + "\t" + intArrayExtra[i] + "p\t\t\t" + categories[i + 5] + "\t:" + intArrayExtra[i + 5] + "p\n";
        }
        return pointsPerRound;
    }

    public int getTotalScore(int[] intArrayExtra) {

        int totalScore = 0;

        for (int i = 0; i < intArrayExtra.length; i++) {
            totalScore += intArrayExtra[i];
        }
        return totalScore;
    }

    @Override
    public String getHallOfFame(String previousHallOfFame, String name, int score) {
        if (previousHallOfFame.equals("")) {
            return score + "//" + name + "//";
        }

        String[] previousHOF = previousHallOfFame.split("//");

        for (int i = 0; i < previousHOF.length; i++) {
            System.out.println(previousHOF[i]);
        }

        int currentScore = score;
        int replaceScore;
        String currentName = name;
        String replaceName;

        for (int i = 0; i < previousHOF.length; i = i + 2) {
            if (Integer.valueOf(previousHOF[i]) <= currentScore) {
                replaceScore = Integer.valueOf(previousHOF[i]);
                replaceName = previousHOF[i + 1];
                previousHOF[i] = String.valueOf(currentScore);
                previousHOF[i + 1] = currentName;
                currentScore = replaceScore;
                currentName = replaceName;
            }
        }
        if (previousHOF.length < 10) {
            String[] newPreviousHOF = new String[previousHOF.length + 2];

            for (int i = 0; i < newPreviousHOF.length; i = i + 2) {
                if (i < newPreviousHOF.length - 2) {
                    newPreviousHOF[i] = previousHOF[i];
                    newPreviousHOF[i + 1] = previousHOF[i + 1];
                } else {
                    newPreviousHOF[newPreviousHOF.length - 2] = String.valueOf(score);
                    newPreviousHOF[newPreviousHOF.length - 1] = name;
                }
            }
            previousHOF = newPreviousHOF;
        }


        for (int i = 0; i < previousHOF.length; i++) {
            System.out.println(previousHOF[i]);
        }

        String newHallOfFame = "";

        for (int i = 0; i < previousHOF.length; i++) {
            if (i < 10) {
                newHallOfFame += previousHOF[i] + "//";
            }
        }
        return newHallOfFame;
    }

    @Override
    public String formatHallOfFame(String newHallOfFame) {

        String[] hallOfFame = newHallOfFame.split("//");

        String formattedHallOfFame;
        formattedHallOfFame = "Hall of fame: \n";

        if (newHallOfFame.equals("")) {
            return formattedHallOfFame;
        }

        int highScorePosition = 1;

        for (int i = 0; i < hallOfFame.length; i = i + 2) {
            formattedHallOfFame += highScorePosition + "# " + hallOfFame[i] + " " + hallOfFame[i + 1] + "\n";
            highScorePosition++;
        }

        return formattedHallOfFame;
    }


}
