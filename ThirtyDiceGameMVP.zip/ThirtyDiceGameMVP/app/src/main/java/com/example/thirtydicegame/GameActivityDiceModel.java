package com.example.thirtydicegame;


import java.util.Random;

/**
 * The type Game activity dice models is a dice roll of 6 die.
 */
public class GameActivityDiceModel implements GameActivityContract.DiceModel {

    public int[] rollDice(int[] dieValues, Boolean[] holdStates) {

        int dice1 = holdStates[0] ? dieValues[0] : new Random().nextInt(6) + 1;
        int dice2 = holdStates[1] ? dieValues[1] : new Random().nextInt(6) + 1;
        int dice3 = holdStates[2] ? dieValues[2] : new Random().nextInt(6) + 1;
        int dice4 = holdStates[3] ? dieValues[3] : new Random().nextInt(6) + 1;
        int dice5 = holdStates[4] ? dieValues[4] : new Random().nextInt(6) + 1;
        int dice6 = holdStates[5] ? dieValues[5] : new Random().nextInt(6) + 1;

        return new int[]{dice1, dice2, dice3, dice4, dice5, dice6};
    }

    public int[] rollDice() {

        int dice1 = new Random().nextInt(6) + 1;
        int dice2 = new Random().nextInt(6) + 1;
        int dice3 = new Random().nextInt(6) + 1;
        int dice4 = new Random().nextInt(6) + 1;
        int dice5 = new Random().nextInt(6) + 1;
        int dice6 = new Random().nextInt(6) + 1;

        return new int[]{dice1, dice2, dice3, dice4, dice5, dice6};
    }
}
